<div class="page-bg">
    <div class="part-title"> {{ $page->title }} </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-center">
                <div class="page-content">
                    {!! $page->text !!}
                </div>
            </div>
        </div>
    </div>
</div>