<!-- Load Scripts -->

{!! Html::script ('assets/libs/jquery.min.js') !!}
{!! Html::script ('assets/libs/jquery.form.min.js') !!}
{!! Html::script ('assets/js/app.js') !!}
{!! Html::script ('assets/js/forms.js') !!}
{!! Html::script ('assets/js/responsiveslides.js') !!}
