@include('front.persian.frame.header')
@yield('content')
@include('front.persian.frame.footer')