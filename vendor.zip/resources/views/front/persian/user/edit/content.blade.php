<div class="page-bg">
    <div class="user-dashboard mt50">
        <div class="container">
            <div class="row">
                @include('front.persian.user.frame.user_right_side_panel')
                <div class="col-sm-5">
                    <section class="panel">
                        <header>
                            <div class="title"> ویرایش پروفایل </div>
                        </header>
                        <article>
                            <div class="field"> <label> نام </label> <input type="text" value="پیمان اسکندری"> </div>
                            <div class="field"> <label> ایمیل </label> <input type="text" value="salam@peyman.me"> </div>
                            <div class="field"> <label> موبایل </label> <input type="text" value="09111233434"> </div>
                            <div class="select">
                                <label> جنسیت </label>
                                <select name="" id="">
                                    <option value="">سلام</option>
                                </select>
                            </div>
                            <div class="field"> <label> رمز عبور </label> <input type="text"> </div>
                            <div class="field"> <label> تکرار رمز عبور </label> <input type="text"> </div>
                            <div class="tal"> <button class="blue ticket-submit"> بروزرسانی </button> </div>
                        </article>
                    </section>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>