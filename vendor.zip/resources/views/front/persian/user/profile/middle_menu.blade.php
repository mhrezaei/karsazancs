<div class="col-sm-3">
    <section class="panel dashboard-item blue">
        <a href="#"> <span class="icon-shopping-cart"></span>
            <div class="title"> {{ trans('front.orders') }} </div>
        </a>
    </section>
</div>
<div class="col-sm-3">
    <section class="panel dashboard-item blue">
        <a href="#"> <span class="icon-money"></span>
            <div class="title"> تراکنش‌ها </div>
        </a>
    </section>
</div>
<div class="col-sm-3">
    <section class="panel dashboard-item blue">
        <a href="#"> <span class="icon-ticket"></span>
            <div class="title"> افزودن تیکت </div>
        </a>
    </section>
</div>
<div class="col-sm-3">
    <section class="panel dashboard-item blue">
        <a href="{{ url('/user/edit') }}"> <span class="icon-cogs"></span>
            <div class="title"> {{ trans('front.user_profile_setting') }} </div>
        </a>
    </section>
</div>