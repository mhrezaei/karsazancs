<section class="panel">
    <header>
        <div class="title"> تازه‌ترین تیکت‌ها </div>
        <div class="functions"> <button class="blue xs"> همه‌ی تیکت‌ها </button> </div>
    </header>
    <article class="ticket-items">
        <div class="ticket-item">
            <div class="col-1"><a href="#">سوال در مورد کارت‌های ۵۰ دلاری</a> </div>
            <div class="col-2">
                <div class="label green">بسته شده</div>
            </div>
        </div>
        <div class="ticket-item">
            <div class="col-1"><a href="#">سوال در مورد کارت‌های ۵۰ دلاری</a> </div>
            <div class="col-2">
                <div class="label red">بسته شده</div>
            </div>
        </div>
        <div class="ticket-item">
            <div class="col-1"><a href="#">سوال در مورد کارت‌های ۵۰ دلاری</a> </div>
            <div class="col-2">
                <div class="label orange">بسته شده</div>
            </div>
        </div>
        <div class="ticket-item">
            <div class="col-1"><a href="#">سوال در مورد کارت‌های ۵۰ دلاری</a> </div>
            <div class="col-2">
                <div class="label gray">بسته شده</div>
            </div>
        </div>
        <div class="ticket-item">
            <div class="col-1"><a href="#">سوال در مورد کارت‌های ۵۰ دلاری</a> </div>
            <div class="col-2">
                <div class="label teal">بسته شده</div>
            </div>
        </div>
    </article>
</section>