@if(0)
	<div>
		@endif

		{!! Form::close() !!}
	</div>
