<div class="btn-group {{{ isset($large) ? 'btn-group-lg' : ''}}} {{{ isset($small) ? 'btn-group-sm' : ''}}} {{{ isset($extrasmall) ? 'btn-group-xs' : ''}}}" role="group" aria-label="...">
  <button type="button" class="btn btn-default">{{$value1}}</button>
  <button type="button" class="btn btn-default">{{$value2}}</button>
  <button type="button" class="btn btn-default">{{$value3}}</button>
  <button type="button" class="btn btn-default">{{$value4}}</button>
</div>
	 