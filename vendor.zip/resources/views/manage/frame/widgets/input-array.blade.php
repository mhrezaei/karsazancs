@include('forms.textarea' , [
	'hint' => trans('manage.settings.downstream_settings.data_type.array_hint') ,
])