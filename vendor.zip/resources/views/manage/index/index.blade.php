@extends('manage.frame.use.0')

@section('page_title' , trans('manage.page_title'))

@section('section')
	12
@endsection