<div style="margin: 40px auto;text-align: center;font-size: 22px;color: #9d9d9d">
	{{ trans('validation.http.Error410') }}
</div>
