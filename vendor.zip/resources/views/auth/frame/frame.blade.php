@include('auth.frame.header')

@yield('content')

@include('auth.frame.footer')