<!-- START: Header -->
<header id="main-header" class="auth">
    <div class="container">
        <a href="{{ url('') }}" id="logo"> <img src="{{ url('/' . Setting::get('site_logo')) }}" width="234"> </a>
    </div>
</header>
<!-- END: Header -->