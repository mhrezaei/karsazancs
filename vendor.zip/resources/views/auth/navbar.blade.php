<header id="main-header" class="auth">
	<div class="container">
		<a href="{{ url('/') }}" id="logo"> <img src="{{url('assets/images/logo.png')}}" width="234"> </a>
	</div>
</header>
