<pre style="direction: ltr">
	{{ print_r($array,true) }}
</pre>