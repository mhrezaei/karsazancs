<?php
return [
	'firm_name' => "دیاموند",
	'admin_page_title' => "دیاموندپنل",
	'dash' => 'ـ',
];